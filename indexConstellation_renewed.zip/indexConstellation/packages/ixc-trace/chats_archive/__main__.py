#!/usr/bin/env python3
"""Entry point for `python -m chats_archive`"""

from chats_archive.cli import main

if __name__ == "__main__":
    main()
