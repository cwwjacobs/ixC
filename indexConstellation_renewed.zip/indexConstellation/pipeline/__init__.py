"""
indexConstellation — Unified Pipeline

Chains NDRP normalization → DiamondScorer quality scoring → filtering → training export.
"""

__version__ = "1.0.0"
